#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char **argv){
	char path[31] = "docs/simulation/";
	char filename[14];
	int ch;
	int i,j,k;
	int choice = atoi(argv[1]);
	for(i=0; i<10; i++){
		strcpy(filename, "sram");
		filename[4] = i + 48;
		strcpy(filename+5, ".txt");
		filename[9] = '\0';
		strcpy(path+16, filename);
		FILE *fptr = fopen(path, "w");
		for(k=0; k<512; k++){
			ch = choice ? (i+k) % 26 + 65 : rand() % 256;
			fputc(ch, fptr);
		}
		fclose(fptr);
	}
	for(i=0; i<10; i++){
		for(j=0; j<8; j++){
			strcpy(filename, "device");
			filename[6] = i + 48;
			filename[7] = '_';
			filename[8] = j + 48;
			strcpy(filename+9, ".txt");
			filename[13] = '\0';
			strcpy(path+16, filename);
			FILE *fptr = fopen(path, "w");
			for(k=0; k<512; k++){
				ch = choice ? (i+j+k) % 26  + 65 : rand() % 256;
				fputc(ch, fptr);
			}
			fclose(fptr);
		}
	}
	return 0;
}
